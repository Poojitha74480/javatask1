package com.hexaware.poojithatask1;

public class lambda{
	public static void main(String[] args) {
		// Lambda Expression
		message m = () -> System.out.println("Quotation method implemented using Lambda Expression");
		m.quotation();
	}
}
